#include "kinematics.hpp"

#include <algorithm>
#include <cmath>
#include <stdexcept>

namespace kinematics
{

namespace
{
constexpr double kPi = 3.14159265358979323846;

inline double deg_to_rad(double degrees)
{
  return degrees * kPi / 180.0;
}

inline double rad_to_deg(double radians)
{
  return radians * 180.0 / kPi;
}

inline double clamp_unit(double value)
{
  return std::clamp(value, -1.0, 1.0);
}

inline double get_param_or_throw(const rclcpp::Node::SharedPtr & node, const std::string & name)
{
  if (!node->has_parameter(name)) {
    node->declare_parameter<double>(name, 0.0);
  }
  return node->get_parameter(name).as_double();
}
}  // namespace

KinematicsSolver::KinematicsSolver(const rclcpp::Node::SharedPtr & node, const std::string & param_prefix)
{
  geometry_.boom_length = get_param_or_throw(node, param_prefix + ".boom_length");
  geometry_.arm_length = get_param_or_throw(node, param_prefix + ".arm_length");
  geometry_.bucket_tooth_length = get_param_or_throw(node, param_prefix + ".bucket_tooth_length");
  geometry_.boom_pivot_x = get_param_or_throw(node, param_prefix + ".boom_pivot_x");
  geometry_.boom_pivot_y = get_param_or_throw(node, param_prefix + ".boom_pivot_y");
  geometry_.boom_pivot_z = get_param_or_throw(node, param_prefix + ".boom_pivot_z");

  limits_.boom_lower = get_param_or_throw(node, param_prefix + ".boom_joint_lower");
  limits_.boom_upper = get_param_or_throw(node, param_prefix + ".boom_joint_upper");
  limits_.arm_lower = get_param_or_throw(node, param_prefix + ".arm_joint_lower");
  limits_.arm_upper = get_param_or_throw(node, param_prefix + ".arm_joint_upper");
  limits_.bucket_lower = get_param_or_throw(node, param_prefix + ".bucket_joint_lower");
  limits_.bucket_upper = get_param_or_throw(node, param_prefix + ".bucket_joint_upper");
}

Pose3D KinematicsSolver::swing_center_forward(const JointState & q) const
{
  const double boom_angle = q.boom;
  const double arm_angle = q.boom + q.arm;
  const double bucket_angle = q.boom + q.arm + q.bucket;

  Pose3D pose{};
  const double radial_distance = geometry_.boom_pivot_x +
    geometry_.boom_length * std::cos(boom_angle) +
    geometry_.arm_length * std::cos(arm_angle) +
    geometry_.bucket_tooth_length * std::cos(bucket_angle);

  pose.x = std::cos(q.swing) * radial_distance;
  pose.y = std::sin(q.swing) * radial_distance + geometry_.boom_pivot_y;
  pose.z = geometry_.boom_pivot_z +
    geometry_.boom_length * std::sin(boom_angle) +
    geometry_.arm_length * std::sin(arm_angle) +
    geometry_.bucket_tooth_length * std::sin(bucket_angle);
  pose.alpha = bucket_angle;
  return pose;
}

Pose2D KinematicsSolver::boom_pivot_forward(const JointState & q) const
{
  const double boom_angle = q.boom;
  const double arm_angle = q.boom + q.arm;
  const double bucket_angle = q.boom + q.arm + q.bucket;

  Pose2D pose{};
  pose.x = geometry_.boom_length * std::cos(boom_angle) +
           geometry_.arm_length * std::cos(arm_angle) +
           geometry_.bucket_tooth_length * std::cos(bucket_angle);
  pose.z = geometry_.boom_length * std::sin(boom_angle) +
           geometry_.arm_length * std::sin(arm_angle) +
           geometry_.bucket_tooth_length * std::sin(bucket_angle);
  pose.alpha = bucket_angle;
  return pose;
}

IkResult KinematicsSolver::swing_center_inverse_by_bucket_angle(const SwingBaseIkRequest & request) const
{
  IkResult result{};
  const Pose3D & target = request.target_pose;
  const double bucket_angle_deg = request.bucket_angle_deg.value_or(rad_to_deg(target.alpha));

  const double swing_rad = std::atan2(target.y - geometry_.boom_pivot_y, target.x);
  const double swing_deg = rad_to_deg(swing_rad);

  const double plane_distance = std::abs(std::cos(swing_rad)) < 1e-9 ?
    (target.y - geometry_.boom_pivot_y) / std::sin(swing_rad) :
    target.x / std::cos(swing_rad);
  const double x_local = plane_distance - geometry_.boom_pivot_x;
  const double z_local = target.z - geometry_.boom_pivot_z;

  const double tip_rad = deg_to_rad(bucket_angle_deg);
  const double x3 = x_local - geometry_.bucket_tooth_length * std::cos(tip_rad);
  const double z3 = z_local - geometry_.bucket_tooth_length * std::sin(tip_rad);
  const double l5 = std::sqrt(x_local * x_local + z_local * z_local);
  const double l6 = std::sqrt(x3 * x3 + z3 * z3);
  if (l5 < 1e-9 || l6 < 1e-9) {
    result.message = "degenerate geometry";
    return result;
  }

  const double cos_beta = (l5 * l5 + l6 * l6 - geometry_.bucket_tooth_length * geometry_.bucket_tooth_length) / (2.0 * l5 * l6);
  const double cos_alpha = (geometry_.boom_length * geometry_.boom_length + l6 * l6 - geometry_.arm_length * geometry_.arm_length) / (2.0 * geometry_.boom_length * l6);
  if (cos_beta < -1.0 || cos_beta > 1.0 || cos_alpha < -1.0 || cos_alpha > 1.0) {
    result.message = "triangle cosine out of range";
    return result;
  }

  const double r = rad_to_deg(std::atan2(z_local, x_local));
  const double b = rad_to_deg(std::acos(clamp_unit(cos_beta)));
  const double a = rad_to_deg(std::acos(clamp_unit(cos_alpha)));

  const double boom_deg = r + b + a;
  const double arm_deg = rad_to_deg(std::acos(clamp_unit((geometry_.boom_length * geometry_.boom_length + geometry_.arm_length * geometry_.arm_length - l6 * l6) / (2.0 * geometry_.boom_length * geometry_.arm_length)))) - 180.0;
  const double bucket_deg = bucket_angle_deg - boom_deg - arm_deg;

  if (!(boom_deg >= limits_.boom_lower && boom_deg <= limits_.boom_upper &&
        arm_deg >= limits_.arm_lower && arm_deg <= limits_.arm_upper &&
        bucket_deg >= limits_.bucket_lower && bucket_deg <= limits_.bucket_upper)) {
    result.message = "joint limits violated";
    return result;
  }

  result.success = true;
  result.q.swing = deg_to_rad(swing_deg);
  result.q.boom = deg_to_rad(boom_deg);
  result.q.arm = deg_to_rad(arm_deg);
  result.q.bucket = deg_to_rad(bucket_deg);
  result.message = "swing-center IK solved";
  return result;
}

IkResult KinematicsSolver::swing_center_inverse_by_bucket_attitude(const SwingBaseIkRequest & request) const
{
  IkResult result{};
  const Pose3D & target = request.target_pose;
  const double bucket_attitude_deg = request.bucket_attitude_deg.value_or(rad_to_deg(target.alpha));

  const double swing_rad = std::atan2(target.y - geometry_.boom_pivot_y, target.x);
  const double swing_deg = rad_to_deg(swing_rad);

  const double plane_distance = std::abs(std::cos(swing_rad)) < 1e-9 ?
    (target.y - geometry_.boom_pivot_y) / std::sin(swing_rad) :
    target.x / std::cos(swing_rad);
  const double x_local = plane_distance - geometry_.boom_pivot_x;
  const double z_local = target.z - geometry_.boom_pivot_z;

  const double tip_rad = deg_to_rad(bucket_attitude_deg);
  const double x3 = x_local - geometry_.bucket_tooth_length * std::cos(tip_rad);
  const double z3 = z_local - geometry_.bucket_tooth_length * std::sin(tip_rad);
  const double l5 = std::sqrt(x_local * x_local + z_local * z_local);
  const double l6 = std::sqrt(x3 * x3 + z3 * z3);
  if (l5 < 1e-9 || l6 < 1e-9) {
    result.message = "degenerate geometry";
    return result;
  }

  const double cos_beta = (l5 * l5 + l6 * l6 - geometry_.bucket_tooth_length * geometry_.bucket_tooth_length) / (2.0 * l5 * l6);
  const double cos_alpha = (geometry_.boom_length * geometry_.boom_length + l6 * l6 - geometry_.arm_length * geometry_.arm_length) / (2.0 * geometry_.boom_length * l6);
  if (cos_beta < -1.0 || cos_beta > 1.0 || cos_alpha < -1.0 || cos_alpha > 1.0) {
    result.message = "triangle cosine out of range";
    return result;
  }

  const double r = rad_to_deg(std::atan2(z_local, x_local));
  const double b = rad_to_deg(std::acos(clamp_unit(cos_beta)));
  const double a = rad_to_deg(std::acos(clamp_unit(cos_alpha)));

  const double boom_deg = r + b + a;
  const double arm_deg = rad_to_deg(std::acos(clamp_unit((geometry_.boom_length * geometry_.boom_length + geometry_.arm_length * geometry_.arm_length - l6 * l6) / (2.0 * geometry_.boom_length * geometry_.arm_length)))) - 180.0;
  const double bucket_deg = bucket_attitude_deg - boom_deg - arm_deg;

  if (!(boom_deg >= limits_.boom_lower && boom_deg <= limits_.boom_upper &&
        arm_deg >= limits_.arm_lower && arm_deg <= limits_.arm_upper &&
        bucket_deg >= limits_.bucket_lower && bucket_deg <= limits_.bucket_upper)) {
    result.message = "joint limits violated";
    return result;
  }

  result.success = true;
  result.q.swing = deg_to_rad(swing_deg);
  result.q.boom = deg_to_rad(boom_deg);
  result.q.arm = deg_to_rad(arm_deg);
  result.q.bucket = deg_to_rad(bucket_deg);
  result.message = "swing-center IK solved";
  return result;
}

IkResult KinematicsSolver::boom_pivot_inverse_by_bucket_attitude(const BoomPivotIkRequest & request) const
{
  IkResult result{};
  const Pose2D & target = request.target_pose;
  const double bucket_attitude_deg = request.bucket_attitude_deg.value_or(rad_to_deg(target.alpha));

  const double x = target.x;
  const double z = target.z;
  const double tip_rad = deg_to_rad(bucket_attitude_deg);
  const double x3 = x - geometry_.bucket_tooth_length * std::cos(tip_rad);
  const double z3 = z - geometry_.bucket_tooth_length * std::sin(tip_rad);
  const double l5 = std::sqrt(x * x + z * z);
  const double l6 = std::sqrt(x3 * x3 + z3 * z3);
  if (l5 < 1e-9 || l6 < 1e-9) {
    result.message = "degenerate geometry";
    return result;
  }

  const double cos_beta = (l5 * l5 + l6 * l6 - geometry_.bucket_tooth_length * geometry_.bucket_tooth_length) / (2.0 * l5 * l6);
  const double cos_alpha = (geometry_.boom_length * geometry_.boom_length + l6 * l6 - geometry_.arm_length * geometry_.arm_length) / (2.0 * geometry_.boom_length * l6);
  if (cos_beta < -1.0 || cos_beta > 1.0 || cos_alpha < -1.0 || cos_alpha > 1.0) {
    result.message = "triangle cosine out of range";
    return result;
  }

  const double r = rad_to_deg(std::atan2(z, x));
  const double b = rad_to_deg(std::acos(clamp_unit(cos_beta)));
  const double a = rad_to_deg(std::acos(clamp_unit(cos_alpha)));

  const double boom_deg = r + b + a;
  const double arm_deg = rad_to_deg(std::acos(clamp_unit((geometry_.boom_length * geometry_.boom_length + geometry_.arm_length * geometry_.arm_length - l6 * l6) / (2.0 * geometry_.boom_length * geometry_.arm_length)))) - 180.0;
  const double bucket_deg = bucket_attitude_deg - boom_deg - arm_deg;

  if (!(boom_deg >= limits_.boom_lower && boom_deg <= limits_.boom_upper &&
        arm_deg >= limits_.arm_lower && arm_deg <= limits_.arm_upper &&
        bucket_deg >= limits_.bucket_lower && bucket_deg <= limits_.bucket_upper)) {
    result.message = "joint limits violated";
    return result;
  }

  result.success = true;
  result.q.boom = deg_to_rad(boom_deg);
  result.q.arm = deg_to_rad(arm_deg);
  result.q.bucket = deg_to_rad(bucket_deg);
  result.message = "boom-pivot IK solved";
  return result;
}

}  // namespace kinematics
