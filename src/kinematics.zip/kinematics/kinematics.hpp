#pragma once

#include <optional>
#include <string>

#include <rclcpp/rclcpp.hpp>

namespace kinematics
{

struct JointState
{
  double swing{0.0};
  double boom{0.0};
  double arm{0.0};
  double bucket{0.0};
};

struct Pose2D
{
  double x{0.0};
  double z{0.0};
  double alpha{0.0};
};

struct Pose3D
{
  double x{0.0};
  double y{0.0};
  double z{0.0};
  double alpha{0.0};
};

struct LinkGeometry
{
  double boom_pivot_x{0.0};
  double boom_pivot_y{0.0};
  double boom_pivot_z{0.0};
  double boom_length{0.0};
  double arm_length{0.0};
  double bucket_tooth_length{0.0};
};

struct JointLimitsDeg
{
  double boom_lower{0.0};
  double boom_upper{0.0};
  double arm_lower{0.0};
  double arm_upper{0.0};
  double bucket_lower{0.0};
  double bucket_upper{0.0};
};

struct IkResult
{
  bool success{false};
  JointState q{};
  std::string message{};
};

struct SwingBaseIkRequest
{
  Pose3D target_pose{};
  std::optional<double> bucket_angle_deg{};
  std::optional<double> bucket_attitude_deg{};
  std::optional<bool> elbow_up{};
};

struct BoomPivotIkRequest
{
  Pose2D target_pose{};
  std::optional<double> bucket_attitude_deg{};
  std::optional<bool> elbow_up{};
};

class KinematicsSolver
{
public:
  explicit KinematicsSolver(const rclcpp::Node::SharedPtr & node, const std::string & param_prefix = "kinematics");

  Pose3D swing_center_forward(const JointState & joint_state) const;
  IkResult swing_center_inverse_by_bucket_angle(const SwingBaseIkRequest & request) const;
  IkResult swing_center_inverse_by_bucket_attitude(const SwingBaseIkRequest & request) const;

  Pose2D boom_pivot_forward(const JointState & joint_state) const;
  IkResult boom_pivot_inverse_by_bucket_attitude(const BoomPivotIkRequest & request) const;

private:
  LinkGeometry geometry_{};
  JointLimitsDeg limits_{};
};

}  // namespace kinematics
